#!/usr/bin/env python3
"""Char-art renderer: lays a .art file onto a monospace grid and outputs PNG (first frame), GIF (when there are several frames) and plain TXT.
@bg background / @fg default text color / @c.name palette (use ⟦name|text⟧ in the body) / @cell cell height px / @pad padding in cells / @fps frame interval ms / @weight regular|bold / @cols @rows fixed canvas (content is centered; @center: no turns it off)
Separate frames with a line containing only ===. Usage: python3 render.py in.art [out_dir]
"""
import sys, os, re, unicodedata, subprocess
from PIL import Image, ImageDraw, ImageFont

def font_path(weight):
    f = 'NotoSansCJK-Bold.ttc' if weight == 'bold' else 'NotoSansCJK-Regular.ttc'
    for d in ('/usr/share/fonts/opentype/noto', '/System/Library/Fonts', os.path.expanduser('~/Library/Fonts')):
        p = os.path.join(d, f)
        if os.path.exists(p): return p
    return subprocess.run(['fc-match', '-f', '%{file}', 'Noto Sans Mono CJK JP'], capture_output=True, text=True).stdout

def face_index(path, family='Noto Sans Mono CJK JP'):
    for i in range(12):
        try:
            f = ImageFont.truetype(path, 20, index=i)
            if f.getname()[0] == family: return i
        except Exception: break
    return 0

def cw(ch):
    if ch == '\t': return 4
    return 2 if unicodedata.east_asian_width(ch) in ('W', 'F') else 1

TOK = re.compile(r'⟦([\w.-]+)\|(.*?)⟧')
def parse_line(line, fg):
    out, i = [], 0
    for m in TOK.finditer(line):
        out += [(c, fg) for c in line[i:m.start()]]
        out += [(c, m.group(1)) for c in m.group(2)]
        i = m.end()
    out += [(c, fg) for c in line[i:]]
    return out

def load(path):
    meta, body = {}, []
    for raw in open(path, encoding='utf-8').read().split('\n'):
        if raw.startswith('@') and ':' in raw and not body:
            k, v = raw[1:].split(':', 1); meta[k.strip()] = v.strip()
        else: body.append(raw)
    frames, cur = [], []
    for l in body:
        if l.strip() == '===': frames.append(cur); cur = []
        else: cur.append(l)
    frames.append(cur)
    frames = [[l.rstrip() for l in f] for f in frames]
    lead = min((next((i for i, l in enumerate(f) if l.strip()), len(f)) for f in frames), default=0)
    frames = [f[lead:] for f in frames]
    for f in frames:
        while f and f[-1] == '': f.pop()
    return meta, frames

def render(path, outdir=None):
    meta, frames = load(path)
    name = os.path.splitext(os.path.basename(path))[0]
    outdir = outdir or os.path.dirname(os.path.abspath(path))
    pal = {k[2:]: v for k, v in meta.items() if k.startswith('c.')}
    bg = meta.get('bg', '#0b0b0b'); pal['fg'] = meta.get('fg', '#f2f2f2')
    H = int(meta.get('cell', 22)); W = H / 2; pad = int(meta.get('pad', 2)); S = 2
    fp = font_path(meta.get('weight', 'regular'))
    font = ImageFont.truetype(fp, int(H * 0.86 * S), index=face_index(fp))
    parsed = [[parse_line(l, 'fg') for l in f] for f in frames]
    cols = max([sum(cw(c) for c, _ in l) for f in parsed for l in f] + [int(meta.get('cols', 0))])
    rows = max([len(f) for f in parsed] + [int(meta.get('rows', 0))])
    bw = max(sum(cw(c) for c, _ in l) for f in parsed for l in f) if any(parsed) else 0
    bh = max(len(f) for f in parsed)
    ox = (cols - bw) // 2 if meta.get('center', 'yes') == 'yes' else 0
    oy = (rows - bh) // 2 if meta.get('center', 'yes') == 'yes' else 0
    Wpx = int((cols + pad * 2) * W * S); Hpx = int((rows + pad * 2) * H * S)
    imgs = []
    for f in parsed:
        im = Image.new('RGB', (Wpx, Hpx), bg); d = ImageDraw.Draw(im)
        for r, line in enumerate(f):
            x = pad + ox
            for ch, col in line:
                w = cw(ch)
                if not ch.isspace():
                    cx = (x + w / 2) * W * S; cy = (pad + oy + r + 0.5) * H * S
                    d.text((cx, cy), ch, font=font, fill=pal.get(col, col), anchor='mm')
                x += w
        imgs.append(im)
    imgs[0].save(os.path.join(outdir, name + '.png'))
    if len(imgs) > 1:
        imgs[0].save(os.path.join(outdir, name + '.gif'), save_all=True, append_images=imgs[1:],
                     duration=int(meta.get('fps', 500)), loop=0)
    plain = '\n'.join(TOK.sub(lambda m: m.group(2), l) for l in frames[0])
    open(os.path.join(outdir, name + '.txt'), 'w', encoding='utf-8').write(plain + '\n')
    return name, len(imgs), cols, rows

if __name__ == '__main__':
    print(render(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None))
