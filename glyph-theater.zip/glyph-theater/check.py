# Self-check: errors, overlap, off frame, accent, shake count; screenshots at each mark; a title-free frame strip for the blind test
import sys,json,time,os
from playwright.sync_api import sync_playwright
from PIL import Image
url=sys.argv[1];secs=float(sys.argv[2]) if len(sys.argv)>2 else 40;out=sys.argv[3] if len(sys.argv)>3 else 'chk'
os.makedirs(out,exist_ok=True)
with sync_playwright() as p:
    try:b=p.chromium.launch()
    except Exception:b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
    pg=b.new_page(viewport={'width':1400,'height':900})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda c:errs.append(c.text) if c.type=='error' else None)
    pg.goto(url+('&' if '?' in url else '?')+'speed=2');pg.wait_for_timeout(500)
    sts=pg.query_selector_all('.st');n=len(sts);frames={i:[] for i in range(n)};marks=[];seen=0;t0=time.time();k=0
    titles=pg.evaluate('STORIES.map(s=>s.title)')
    while time.time()-t0<secs:
        ms=pg.evaluate('window.__marks||[]')
        for m in ms[seen:]:
            i=titles.index(m['story']);f=f'{out}/m{len(marks)}.png';sts[i].screenshot(path=f);marks.append((m['story'],m['label'],f))
        seen=len(ms)
        if k%4==0:
            for i in range(n):f=f'{out}/s{i}_{len(frames[i])}.png';sts[i].screenshot(path=f);frames[i].append(f)
        k+=1;pg.wait_for_timeout(250)
    rep=pg.evaluate('window.__report');b.close()
print('errors:',errs[:5] or 'none')
for r in rep:print(r['story'],'→',r['warnings'] or 'ok')
for i in range(n):
    ims=[Image.open(f) for f in frames[i]][:24];w,h=ims[0].size;s=.45;W,H=int(w*s),int(h*s);cols=6
    sheet=Image.new('RGB',(W*cols,H*((len(ims)+cols-1)//cols)),'#ccc')
    for j,im in enumerate(ims):sheet.paste(im.resize((W,H)),((j%cols)*W,(j//cols)*H))
    sheet.save(f'{out}/blind_{i}.png')
json.dump(marks,open(f'{out}/marks.json','w'),ensure_ascii=False)
print('marks:',[(a,b) for a,b,_ in marks][:30])
